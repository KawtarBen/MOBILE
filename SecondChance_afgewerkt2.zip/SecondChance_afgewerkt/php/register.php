<?php

global $connection;
include './config.php';

	if(isset($_POST['registreren'])){ 		
		
		$Rnummer = $connection->real_escape_string($_POST['Rnummer']);
		$email = $connection->real_escape_string($_POST['email']); 
		$wachtwoord = ($connection->real_escape_string($_POST['wachtwoord']));
		
	
		$data = $connection->query("select id from vilfoodia_one_sc where Rnummer = '$Rnummer'");

		if($data -> num_rows > 0){ 
            
            exit('username bestaat');
		}else{ 
			$sql = "INSERT INTO Users (Rnummer,email,wachtwoord) VALUES ('$Rnummer', '$email', '$wachtwoord')";
			if ($connection->query($sql) === TRUE) { 
                exit('{"message": "login success"}'); 
			} else {
                exit('{"message": "login failed"}');
			}
			
			$connection->close(); // connectie afsluiten
		}			
		}


 /*

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
header('Access-Control-Max-Age: 1000');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

    $con = mysqli_connect('vilfoodia.one.mysql', 'vilfoodia_one_sc', '3htb16', "vilfoodia_one_sc");

    if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
    } 



    $Rnummer = $_POST["Rnummer"];
    $email = $_POST["email"];
    $wachtwoord = $_POST["wachtwoord"];



s
    $sql = msqli_query($con, "INSERT INTO Users (Rnummer, email, wachtwoord) VALUES (?, ?, ?)");
    mysqli_stmt_bind_param($sql, "s", $Rnummer, $email, $wachtwoord);
    mysqli_stmt_execute($sql);


    function registerUser() {

        global $connect, $Rnummer, $email, $wachtwoord;

        $passwordHash = password_hash($wachtwoord, PASSWORD_DEFAULT);

        $statement = mysqli_prepare($connect, "INSERT INTO users (Rnummer, email, wachtwoord) VALUES (?, ?, ?)")
        mysqli_stmt_bind_param($statement, "s", $Rnummer, $email, $passwordHash);

        mysqli_stmt_execute($statement);

        mysqli_stmt_close($statement);     

    }



    function usernameAvailable() {

        global $connect, $Rnummer;

        $statement = mysqli_prepare($connect, "SELECT * FROM users WHERE Rnummer = ?"); 

        mysqli_stmt_bind_param($statement, "s", $Rnummer);

        mysqli_stmt_execute($statement);

        mysqli_stmt_store_result($statement);

        $count = mysqli_stmt_num_rows($statement);

        mysqli_stmt_close($statement); 

        if ($count < 1){

            return true; 

        }else {

            return false; 

        }

    }



    $response = array();

    $response["success"] = false;  



    if (usernameAvailable()){

        registerUser();

        $response["success"] = true;  

    }

    

    echo json_encode($response);
    */


?>
