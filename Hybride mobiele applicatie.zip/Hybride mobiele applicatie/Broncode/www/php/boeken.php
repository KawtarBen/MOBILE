<?php
      
global $connection;
include './config.php';

	if(isset($_POST['toevoegen'])){ 
		$titel = $connection->real_escape_string($_POST['titel']);
		$jaar = $connection->real_escape_string($_POST['jaar']); 
		$prijs = ($connection->real_escape_string($_POST['prijs']));
		
	
		$data = $connection->query("select 'titel' from vilfoodia_one_sc where 'boeken' = '$titel'");

		if($data->num_rows > 0){ 
		}
        
        else{ 
			$sql = "INSERT INTO boeken (titel,jaar,prijs) VALUES ('$titel', '$jaar', '$prijs')";
			if ($connection->query($sql) === TRUE) { // als het gelukt is geven we in de console mee 
                exit('{"message": "adding success"}'); 
			} else {
                exit('{"message": " adding failed"}');
			}
			
			$connection->close(); // connectie afsluiten
		}			
		}
    ?>