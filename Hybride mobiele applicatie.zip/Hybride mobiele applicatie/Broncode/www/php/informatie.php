<?php
global $connection;
include './config.php';

function fetchData($sql, $connection){
    $return = array();
    if(!$connection){
        die("Geen databank verbinding");
    }else{
        $result = $connection -> query($sql);
        while ($row = $result -> fetch_assoc()){
            $return[count($return)] = $row;
        }
    }
    return $return;
}
$resultaat = fetchData("SELECT Rnummer from Users", $conn);

for($i = 0; $i < count($resultaat); $i++){
    echo"<span class='rij'><span class='kolom1'>". $resultaat[$i]["Rnummer"]."</span><span class='kolom2'>".resultaat[$i]["email"]."</span>";
}

?>

<style>
    .rij{
    clear:both;
    float:left;
    margin-left:0.25em;
    margin-right:0.25em;
}
    .kolom1, .kolom2{
        display:inline-block;
        width: 3em;
        background-color:lightgrey;
    }
</style>
    